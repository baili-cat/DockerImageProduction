#!/bin/bash

set -e

# 注意: 在某些操作系统(ubuntu)下面使用grep命令匹配不到值时，会返回错误码1导致脚本中断
echo "INFO: checking if shell is bash"
CURRENT_SHELL=$(ls -al /bin/sh | grep "bash") || true
if [ -z "$CURRENT_SHELL" ]; then
    echo "ERROR: 当前系统默认使用的SHELL不支持，可通过此命令: ln -fs /bin/bash /bin/sh  切换为为bash" 1>&2
    exit 1
fi

#进入当前命令目录
INSTALL_HOME="$(cd "$(dirname "$0")" && pwd)"

#系统检查
system_check() {
    echo "INFO: checking if systemctl is installed"
    if ! systemctl --version &>/dev/null; then
        echo "ERROR: 缺少系统命令[systemctl]，可通过此命令安装: apt-get install -y systemd" 1>&2
        exit 1
    fi

    echo "INFO: checking if docker is installed"
    if docker --version &>/dev/null; then
        docker_version=$(docker --version | awk -F "," '{print $1}')
        echo "ERROR: check if $docker_version is installed，请先卸载重装" 1>&2
        exit 1
    fi

    echo "INFO: checking if docker-compose is installed"
    if docker-compose --version &>/dev/null; then
        docker_compose_version=$(docker-compose version --short)
        echo "ERROR: check if docker-compose($docker_compose_version) is installed，请先卸载重装" 1>&2
        exit 1
    fi

    # Docker数据目录磁盘空间检查
    echo "INFO: checking docker.dataDir($DOCKER_DATA_DIR) available disk space"
    if [ -z "$DOCKER_DATA_DIR" ]; then
        echo "ERROR: 'DOCKER_DATA_DIR' is not set" 1>&2
        exit 1
    fi
    if [ -z "$DOCKER_DATA_DISK_SIZE" ]; then
        echo "ERROR: 'DOCKER_DATA_DISK_SIZE' is not set" 1>&2
        exit 1
    fi
    if [ ! -d "$DOCKER_DATA_DIR" ]; then
        mkdir -p $DOCKER_DATA_DIR
    fi
    availableSize=$(df -T --block-size=1G $DOCKER_DATA_DIR | awk '{if (NR>1){print $5}}' | tr -s \" \")
    if [ ${availableSize} -lt ${DOCKER_DATA_DISK_SIZE} ]; then
        echo "ERROR: Docker数据目录($DOCKER_DATA_DIR)所在磁盘分区空间不足, 剩余可用大小:${availableSize}GB 至少需要${DOCKER_DATA_DISK_SIZE}GB空间"
        exit 1
    else
        echo "INFO: Docker数据目录($DOCKER_DATA_DIR)所在磁盘分区空间剩余可用大小:${availableSize}GB"
    fi
}

configure_sysconfig() {
    #禁用防火墙
    # centos
    if ! systemctl disable firewalld --now &>/dev/null; then
        echo "INFO: firewalld is not installed, skip"
    else
        echo "INFO: systemctl disable firewalld"
    fi

    # ubuntu
    if ! systemctl disable ufw --now &>/dev/null; then
        echo "INFO: ufw is not installed, skip"
    else
        echo "INFO: systemctl disable ufw"
    fi

    #禁用SELINUX, 查看状态命令 sestatus
    if getenforce &>/dev/null; then
        if [ "$(getenforce)" != "Disabled" ]; then
            setenforce 0
        fi
        if [ -f "/etc/selinux/config" ]; then
            #sed -i '/^SELINUX=/c\SELINUX=disabled' /etc/selinux/config
            touch /etc/selinux/config
        fi
        sed -i '/^SELINUX=/d' /etc/selinux/config
        echo "SELINUX=disabled" >/etc/selinux/config
        echo "INFO: disable selinux, /etc/selinux/config > 'SELINUX=disabled'"
    else
        echo "INFO: selinux is not installed, skip"
    fi

    sysctl -w net.ipv4.ip_forward=1
    echo "net.ipv4.ip_forward=1" >/etc/sysctl.d/perfma-docker.conf
    echo "INFO: net.ipv4.ip_forward=1"

    #关闭Swap分区
    swapoff -a && sysctl -w vm.swappiness=0
    sed -ri '/^[^#]*swap/s@^@#@' /etc/fstab
    echo "vm.swappiness=0" >/etc/sysctl.d/perfma.conf
    echo "INFO: disable swap"

    #修改vm.max_map_count大小
    sed -i '/^vm.max_map_count=/d' /etc/sysctl.conf
    echo "vm.max_map_count=262144" >>/etc/sysctl.conf && sysctl -p
    echo "INFO: write (/etc/sysctl.conf) vm.max_map_count=262144"

    #服务器时区配置
    if [ -f "/usr/share/zoneinfo/Asia/Shanghai" ]; then
        rm -rf /etc/localtime
        cp -f /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
        echo "INFO: set timezone(/usr/share/zoneinfo/Asia/Shanghai -> /etc/localtime)"
    else
        echo "WARN: set timezone(/usr/share/zoneinfo/Asia/Shanghai) does not exist"
    fi

    # TODO /usr/local/bin写入到/etc/profile，SSH连接还是可能不会加载/etc/profile
    retval=$(env | grep PATH | grep /usr/local/bin) || true
    if [ -z "$retval" ]; then
        echo "export PATH=\$PATH:/usr/local/bin" >>/etc/profile
        echo "export PATH=\$PATH:/usr/local/bin" >>/etc/bashrc
        # 操作系统安装了图形界面时，执行【/etc/profile.d/im-config_wayland.sh】可能会导致直接return导致安装失败
        source /etc/profile || true
        source /etc/bashrc || true
        echo "INFO: export PATH=\$PATH:/usr/local/bin >>/etc/profile"
        echo "INFO: export PATH=\$PATH:/usr/local/bin >>/etc/bashrc"
    fi

    #yum -y install ntpdate
    ##crontab -e
    #echo '30 5 * * * /usr/sbin/ntpdate cn.pool.ntp.org' > /var/spool/cron/root
    #systemctl restart crond
    #echo "服务器时区配置完成"
}

install_docker() {
    # install docker
    if [ -n "$docker_version" ]; then
        echo "INFO: Use installed docker($docker_version)"
    else
        if [ -z "$DOCKER_LOG_MAX_SIZE" ]; then
            echo "ERROR: 'DOCKER_LOG_MAX_SIZE' is not set" 1>&2
            exit 1
        fi
        if [ -z "$DOCKER_LOG_MAX_FILE" ]; then
            echo "ERROR: 'DOCKER_LOG_MAX_FILE' is not set" 1>&2
            exit 1
        fi
        if [ -z "$DOCKER_DATA_DIR" ]; then
            echo "ERROR: 'DOCKER_DATA_DIR' is not set" 1>&2
            exit 1
        fi

        #写入docker配置
        DAEMON_CONF_FILE="/etc/docker/daemon.json"
        mkdir -p /etc/docker
        echo "INFO: write \"$DAEMON_CONF_FILE\" config"
        cat >$DAEMON_CONF_FILE <<EOF
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "${DOCKER_LOG_MAX_SIZE}",
    "max-file": "${DOCKER_LOG_MAX_FILE}"
  },
  "graph": "${DOCKER_DATA_DIR}"
}
EOF
        cat $DAEMON_CONF_FILE

        #复制docker二进制运行文件
        for name in "$INSTALL_HOME"/docker/bin/*; do
            name=$(basename "${name}")
            if [ "$name" != "docker-compose" ]; then
                echo "INFO: copy docker-bin[$name] to /usr/local/bin/$name"
                cp -f "$INSTALL_HOME/docker/bin/$name" /usr/local/bin/
                chmod +x "/usr/local/bin/$name"
            fi
        done

        #设置docker开启自启动
        echo "INFO: copy docker.service to /usr/lib/systemd/system/docker.service"
        mkdir -p /usr/lib/systemd/system
        cp -f "$INSTALL_HOME/docker/docker.service" /usr/lib/systemd/system

        echo "INFO: enable & starting docker.service..."
        systemctl enable docker.service --now

        echo "INFO: docker($(docker version -f '{{.Server.Version}}')) is installed"
    fi

    # install docker-compose
    if [ -n "$docker_compose_version" ]; then
        echo "INFO: Use installed docker-compose($docker_compose_version)"
    else
        echo "INFO: copy docker-compose to /usr/local/bin/docker-compose"
        cp -f "$INSTALL_HOME/docker/bin/docker-compose" /usr/local/bin/
        chmod +x /usr/local/bin/docker-compose

        echo "INFO: docker-compose($(docker-compose version --short)) is installed"
    fi
}

configure_docker_network() {
    if [ -z "$DOCKER_NETWORK_NAME" ]; then
        echo "ERROR: 'DOCKER_NETWORK_NAME' is not set" 1>&2
        exit 1
    fi

    if [ -z "$DOCKER_NETWORK_SUBNET" ]; then
        echo "ERROR: 'DOCKER_NETWORK_SUBNET' is not set" 1>&2
        exit 1
    fi

    network_id=$(docker network ls -f "name=${DOCKER_NETWORK_NAME}" -q)
    if [ -z "${network_id}" ]; then
        docker network create --driver=bridge --subnet=${DOCKER_NETWORK_SUBNET} ${DOCKER_NETWORK_NAME}
        echo "INFO: create docker network{name='$DOCKER_NETWORK_NAME', driver='bridge', subnet='$DOCKER_NETWORK_SUBNET'}"
    else
        docker_network_subnet=$(docker network inspect "${network_id}" -f "{{(index .IPAM.Config 0).Subnet}}")
        echo "INFO: use docker network{name='$DOCKER_NETWORK_NAME', driver='bridge', subnet='$docker_network_subnet'}"
    fi
}

install_base_service() {
    image_file=$(find "$INSTALL_HOME/$1" -maxdepth 1 -type f -name "$1-*.tar.gz")
    echo "INFO: loading \"$1\" image file \"$image_file\""
    docker load -i "$image_file"

    echo "INFO: copy docker-compose.yml to /var/opt/$1/docker-compose.yml"
    mkdir -p "/var/opt/$1"
    cp -f "$INSTALL_HOME/$1/docker-compose.yml" "/var/opt/$1"
    sed -i "s/\${DOCKER_NETWORK_NAME}/$DOCKER_NETWORK_NAME/g" "/var/opt/$1/docker-compose.yml"
    sed -i "s/\${DOCKER_DATA_DIR}/$(printf '%s' "${DOCKER_DATA_DIR}" | sed 's/[-#\/]/\\\0/g')/g" "/var/opt/$1/docker-compose.yml"
    sed -i "s/\${CONTAINER_PORT}/$2/g" "/var/opt/$1/docker-compose.yml"

    echo "INFO: starting $1..."
    docker-compose -f "/var/opt/$1/docker-compose.yml" up --no-start
    docker-compose -f "/var/opt/$1/docker-compose.yml" start
    echo "INFO: $1 is installed"
}

install() {
    PERFMA_XSHELTER_INSTALLED="$(grep "PERFMA_XSHELTER_INSTALLED=" /etc/profile)" || true
    if [ -z "${PERFMA_XSHELTER_INSTALLED}" ]; then
        echo "**************************** Begin System Check ****************************"
        system_check

        echo "**************************** Begin SysConfig configure ****************************"
        configure_sysconfig

        echo "**************************** Begin Docker install ****************************"
        install_docker

        echo "**************************** Begin Docker network configure ****************************"
        configure_docker_network

#        echo "**************************** Begin NodeExporter install ****************************"
#        if [ -z "$DOCKER_NODE_EXPORTER_PORT" ]; then
#            echo "ERROR: 'DOCKER_NODE_EXPORTER_PORT' is not set" 1>&2
#            exit 1
#        fi
#        install_base_service "node-exporter" "$DOCKER_NODE_EXPORTER_PORT"
#
#        echo "**************************** Begin cAdvisor install ****************************"
#        if [ -z "$DOCKER_CADVISOR_PORT" ]; then
#            echo "ERROR: 'DOCKER_CADVISOR_PORT' is not set" 1>&2
#            exit 1
#        fi
#        install_base_service "cadvisor" "$DOCKER_CADVISOR_PORT"
    else
        echo "WARN: 当前服务器环境已由方舱安装初始化，跳过Docker环境初始化"
    fi
}

clean() {
    echo "**************************** Docker uninstall ****************************"
    echo "INFO: 开始执行 [Docker环境] 卸载操作..."

    RETVAL=0
    if docker info &>/dev/null; then
        DOCKER_DATA_DIR="$(docker info | grep "Docker Root Dir:" | awk -F ': ' '{print $2}')" || true

        echo "INFO: stop all containers"
        container_ids="$(docker container ls -a -q)"
        if [ -n "$container_ids" ]; then
            docker container stop -t 3 ${container_ids}
        fi

        echo "INFO: remove all [containers,networks,volumes,images]"
        docker system prune -a -f --volumes

        echo "INFO: disable & stop docker.service"
        systemctl disable docker.service --now || true
        RETVAL=1
    fi

    # docker dataDir
    if [ -z "$DOCKER_DATA_DIR" ]; then
        if [ -f "/etc/docker/daemon.json" ]; then
            DOCKER_DATA_DIR="$(grep "\"graph\":" /etc/docker/daemon.json | awk -F ':' '{print $2}' | awk -F '"' '{print $2}')" || true
        fi

        if [ -z "$DOCKER_DATA_DIR" ] || [ "$DOCKER_DATA_DIR" = "/" ]; then
            DOCKER_DATA_DIR="/var/lib/docker"
            echo "INFO: Use default docker dataDir: $DOCKER_DATA_DIR"
        fi
    fi

    # docker dataDir
    if [ -d "$DOCKER_DATA_DIR" ]; then
        echo "INFO: remove docker dataDir: $DOCKER_DATA_DIR"
        rm -rf $DOCKER_DATA_DIR
        RETVAL=1
    fi

    # docker configDir
    if [ -d "/etc/docker" ]; then
        echo "INFO: remove docker configDir: /etc/docker"
        rm -rf /etc/docker
        RETVAL=1
    fi

    # docker service
    if [ -f "/usr/lib/systemd/system/docker.service" ]; then
        echo "INFO: remove /usr/lib/systemd/system/docker.service"
        rm -rf /usr/lib/systemd/system/docker.service
        RETVAL=1
    fi

    # node-exporter
    if [ -d "/var/opt/node-exporter" ]; then
        echo "INFO: remove node-exporter: /var/opt/node-exporter"
        rm -rf /var/opt/node-exporter
        RETVAL=1
    fi

    # cadvisor
    if [ -d "/var/opt/cadvisor" ]; then
        echo "INFO: remove cadvisor: /var/opt/cadvisor"
        rm -rf /var/opt/cadvisor
        RETVAL=1
    fi

    # 18.09.x, 19.03.x, 19.03.x
    #docker-compose、docker、docker-init、docker-proxy、dockerd
    #runc、ctr、containerd、containerd-shim
    # 20.10.x
    #containerd-shim-runc-v2
    # 17.x-ce, 18.x-ce
    #docker-runc、docker-containerd、docker-containerd-ctr、docker-containerd-shim

    # docker file
    find_dirs=("/bin/" "/sbin/" "/usr/local/bin/" "/usr/local/sbin/" "/usr/bin/" "/usr/sbin/")
    find_prefixs=("docker*" "containerd*" "runc" "ctr")
    for find_dir in "${find_dirs[@]}"; do
        for find_prefix in "${find_prefixs[@]}"; do
            for file in $(find "$find_dir" -maxdepth 1 -type f -name "$find_prefix"); do
                echo "INFO: remove docker: $file"
                rm -f "$file"
                RETVAL=1
            done
        done
    done

    if [ $RETVAL = 1 ]; then
        echo "INFO: 当前服务器 [Docker环境] 卸载完成, 请「重启服务器」完成残留运行时数据清理"
    else
        echo "INFO: 当前环境未检测到Docker安装文件"
    fi
}

DOCKER_CONF_FILE="$INSTALL_HOME/docker.conf"
read_config() {
    if [ ! -f "$DOCKER_CONF_FILE" ]; then
        echo "ERROR: '$DOCKER_CONF_FILE' does not exist" 1>&2
        exit 1
    fi

    val=$(grep "$1" "$DOCKER_CONF_FILE" | awk -F "$1=" '{print $2}') || true
    if [ -z "$val" ]; then
        echo "ERROR: Config '${1}' is not set" 1>&2
        exit 1
    fi
    echo "$val"
}

# 通过传入参数方式
# 安装: sh ./install.sh install "100m" "5" "/var/lib/docker" "xshelter_network_default" "172.20.0.0/16"
# 卸载: sh ./install.sh clean
case $1 in
install)
    if [ $# -ge 5 ]; then
        echo "INFO: 设置Docker安装参数来源：命令参数"
        DOCKER_LOG_MAX_SIZE=$2
        DOCKER_LOG_MAX_FILE=$3
        DOCKER_DATA_DIR=$4
        DOCKER_DATA_DISK_SIZE=$5
        DOCKER_NETWORK_NAME=$6
        DOCKER_NETWORK_SUBNET=$7
#        DOCKER_CADVISOR_PORT=$8
#        DOCKER_NODE_EXPORTER_PORT=$9
    else
        echo "INFO: 设置Docker安装参数来源：本地配置文件docker.conf"
        DOCKER_LOG_MAX_SIZE=$(read_config "docker.log.max-size")
        DOCKER_LOG_MAX_FILE=$(read_config "docker.log.max-file")
        DOCKER_DATA_DIR=$(read_config "docker.data.dir")
        DOCKER_DATA_DISK_SIZE=$(read_config "docker.data.disk-size")
        DOCKER_NETWORK_NAME=$(read_config "docker.network.name")
        DOCKER_NETWORK_SUBNET=$(read_config "docker.network.subnet")
#        DOCKER_CADVISOR_PORT=$(read_config "docker.cadvisor.port")
#        DOCKER_NODE_EXPORTER_PORT=$(read_config "docker.node-exporter.port")
        if [ -z "$DOCKER_CADVISOR_PORT" ]; then
            DOCKER_CADVISOR_PORT="9101"
        fi
        if [ -z "$DOCKER_NODE_EXPORTER_PORT" ]; then
            DOCKER_NODE_EXPORTER_PORT="9100"
        fi
    fi

    echo "docker.log.max-size: $DOCKER_LOG_MAX_SIZE"
    echo "docker.log.max-file: $DOCKER_LOG_MAX_FILE"
    echo "docker.data.dir: $DOCKER_DATA_DIR"
    echo "docker.data.disk-size: $DOCKER_DATA_DISK_SIZE"
    echo "docker.network.name: $DOCKER_NETWORK_NAME"
    echo "docker.network.subnet: $DOCKER_NETWORK_SUBNET"
    echo "docker.cadvisor.port: $DOCKER_CADVISOR_PORT"
    echo "docker.node-exporter.port: $DOCKER_NODE_EXPORTER_PORT"

    if [ "$DOCKER_DATA_DIR" = "/" ]; then
        echo "ERROR: Docker数据目录禁止设置为系统根路径: '/'"
        exit 1
    fi

    install
    ;;
clean)
    clean
    ;;
*)
    echo $"Usage: $0 install|clean"
    ;;
esac

exit 0
